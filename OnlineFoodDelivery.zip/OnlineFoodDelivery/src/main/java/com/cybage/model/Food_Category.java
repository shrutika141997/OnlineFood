package com.cybage.model;


import java.util.List;

import javax.persistence.CascadeType;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.OneToMany;

import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonProperty.Access;


@Entity
public class Food_Category {
	@Id
	@GeneratedValue(strategy=GenerationType.IDENTITY)
	private int food_Category_Id;
	private String food_Category_Name;
	
	@OneToMany(mappedBy="foodCategory",cascade = CascadeType.ALL)
	@JsonProperty(access = Access.READ_ONLY)
	
	private List<Food_Details> food_Details ;
	
	
	public Food_Category() {
		super();
	}

	

	



	public Food_Category(int food_Category_Id, String food_Category_Name, List<Food_Details> food_Details) {
		super();
		this.food_Category_Id = food_Category_Id;
		this.food_Category_Name = food_Category_Name;
		this.food_Details = food_Details;
	}







	public int getFood_Category_Id() {
		return food_Category_Id;
	}

	public void setFood_Category_Id(int food_Category_Id) {
		this.food_Category_Id = food_Category_Id;
	}

	public String getFood_Category_Name() {
		return food_Category_Name;
	}

	public void setFood_Category_Name(String food_Category_Name) {
		this.food_Category_Name = food_Category_Name;
	}
	

	

	public List<Food_Details> getFood_Details() {
		return food_Details;
	}







	public void setFood_Details(List<Food_Details> food_Details) {
		this.food_Details =food_Details;
		for(Food_Details food : food_Details)
			food.setFoodCategory(this);
	}







	@Override
	public String toString() {
		return "Food_Category [food_Category_Id=" + food_Category_Id + ", food_Category_Name=" + food_Category_Name
				+ ", food_Details=" + food_Details + "]";
	}







	
	
	
	

}
