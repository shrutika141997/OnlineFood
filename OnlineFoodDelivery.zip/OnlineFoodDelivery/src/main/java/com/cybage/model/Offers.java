package com.cybage.model;



import javax.persistence.CascadeType;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.OneToOne;
import javax.persistence.Table;



@Entity
@Table(name="offer")
public class Offers {
	@Id
	@GeneratedValue(strategy=GenerationType.IDENTITY)
	private int offer_Id;
	private int offer;
	@OneToOne(cascade=CascadeType.ALL,mappedBy="offer")
	private Food_Details food_details;
	
	
	
	public Offers() {
		super();
	}


	public Offers(int offer_Id, int offer) {
		super();
		this.offer_Id = offer_Id;
		this.offer = offer;
		
	
	}










	public int getOffer_Id() {
		return offer_Id;
	}


	public void setOffer_Id(int offer_Id) {
		this.offer_Id = offer_Id;
	}



	


	public int getOffer() {
		return offer;
	}


	public void setOffer(int offer) {
		this.offer = offer;
	}


	@Override
	public String toString() {
		return "Offers [offer_Id=" + offer_Id + ", offer=" + offer + ", food_details=" + food_details + "]";
	}


	
	
	
	
	
	

}
