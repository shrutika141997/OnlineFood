package com.cybage.model;

import javax.persistence.CascadeType;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.OneToOne;

import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonProperty.Access;

@Entity
public class Food_Details {
	
	@Id
	@GeneratedValue(strategy=GenerationType.IDENTITY)
	private int food_Id;
	private String food_Name;
	private int food_Price;
	
	@ManyToOne(cascade = CascadeType.ALL)
	@JoinColumn(name="categoryId",nullable=false)
	@JsonProperty(access = Access.WRITE_ONLY)
	
	private Food_Category foodCategory;
	
	@OneToOne(cascade=CascadeType.ALL)
	@JoinColumn(name="offer",nullable=false)
	private Offers offer;
	
	public Food_Details() {
		super();
	}


	public Food_Details(int food_Id, String food_Name, int food_Price, Food_Category foodCategory, Offers offer) {
		super();
		this.food_Id = food_Id;
		this.food_Name = food_Name;
		this.food_Price = food_Price;
		this.foodCategory = foodCategory;
		this.offer = offer;
	}













	public int getFood_Id() {
		return food_Id;
	}


	public void setFood_Id(int food_Id) {
		this.food_Id = food_Id;
	}


	public String getFood_Name() {
		return food_Name;
	}


	public void setFood_Name(String food_Name) {
		this.food_Name = food_Name;
	}


	public int getFood_Price() {
		return food_Price;
	}


	public void setFood_Price(int food_Price) {
		this.food_Price = food_Price;
	}


	public Food_Category getFoodCategory() {
		return foodCategory;
	}


	public void setFoodCategory(Food_Category foodCategory) {
		this.foodCategory = foodCategory;
	}

	

	public Offers getOffer() {
		return offer;
	}


	public void setOffer(Offers offer) {
		this.offer = offer;
	}


	@Override
	public String toString() {
		return "Food_Details [food_Id=" + food_Id + ", food_Name=" + food_Name + ", food_Price=" + food_Price
				+ ", foodCategory=" + foodCategory + ", offer=" + offer + "]";
	}


	
	
	

	

	
}
