package com.cybage.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;


import com.cybage.model.Offers;

import com.cybage.service.Offer_Service;

@RestController
public class Offer_Controller {

	@Autowired
	Offer_Service offer_Service;
	
	
	
	
	@PostMapping("/allOffer")
	public List<Offers> getAll()
	{
		return offer_Service.getAll();
	}
	@PostMapping("/addOffer")
	public ResponseEntity<String> addOffer(@RequestBody Offers offer){
		offer_Service.addOffer(offer);
		System.out.println(offer);
		return new ResponseEntity<String>("Offer added successfully", HttpStatus.CREATED);
	}
	@DeleteMapping("/deleteOffer/{id}")
	// Path variable---->its a spring boot annotation to handle template variables in the request URI mapping, and set them as method parameters
	public ResponseEntity<String> deleteOffer(@PathVariable int id){
		offer_Service.deleteOffer(id);
		return new ResponseEntity<String>("Offer deleted successfully", HttpStatus.OK);
	}
	@PutMapping("/updateOffer/{id}")
	//Response Body--> to handle template variables in the request URI mapping, and set them as method parameters
	public ResponseEntity<String> updateOffer(@PathVariable int id, @RequestBody Offers offer){
		offer_Service.updateOffer(id, offer);
		return new ResponseEntity<String>("Offer update successfully", HttpStatus.OK);
	}
}
