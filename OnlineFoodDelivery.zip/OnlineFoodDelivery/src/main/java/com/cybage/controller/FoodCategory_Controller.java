package com.cybage.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.cybage.model.Food_Category;
import com.cybage.model.Food_Details;
import com.cybage.service.FoodCategory_Service;
import com.cybage.service.FoodDetails_Service;

@RestController
public class FoodCategory_Controller {
	
	@Autowired
	FoodCategory_Service foodCategoryService;
	
	@Autowired
	FoodDetails_Service foodDetailsService;
	
	
	@PostMapping("/foodCategory")
	public List<Food_Category> getAll()
	{
		return foodCategoryService.getAll();
	}
	@PostMapping("/addCategory")
	public ResponseEntity<String> addCategory(@RequestBody Food_Category food){
		foodCategoryService.addCategory(food);
		System.out.println(food);
		return new ResponseEntity<String>("Category added successfully", HttpStatus.CREATED);
	}
	@DeleteMapping("/deleteCategory/{id}")
	// Path variable---->its a spring boot annotation to handle template variables in the request URI mapping, and set them as method parameters
	public ResponseEntity<String> deleteCategory(@PathVariable int id){
		foodCategoryService.deleteCategory(id);
		return new ResponseEntity<String>("Category deleted successfully", HttpStatus.OK);
	}
	@PutMapping("/updateCategory/{id}")
	//Response Body--> to handle template variables in the request URI mapping, and set them as method parameters
	public ResponseEntity<String> updateCategory(@PathVariable int id, @RequestBody Food_Category food){
		foodCategoryService.updateCategory(id, food);
		return new ResponseEntity<String>("Category update successfully", HttpStatus.OK);
	}
	

}
