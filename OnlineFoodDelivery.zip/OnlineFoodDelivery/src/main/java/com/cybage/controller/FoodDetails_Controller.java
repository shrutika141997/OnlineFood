package com.cybage.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.cybage.model.Food_Details;
import com.cybage.service.FoodCategory_Service;
import com.cybage.service.FoodDetails_Service;

@RestController
public class FoodDetails_Controller {

	@Autowired
	FoodCategory_Service foodCategoryService;
	
	@Autowired
	FoodDetails_Service foodDetailsService;
	
	
	@GetMapping("/allFood")
	public List<Food_Details> getAll()
	{
		return foodDetailsService.getAll();
	}
	@PostMapping("/addFood")
	public ResponseEntity<String> addFood(@RequestBody Food_Details food){
		foodDetailsService.addFood(food);
		System.out.println(food);
		return new ResponseEntity<String>("Food added successfully", HttpStatus.CREATED);
	}
	@DeleteMapping("/deleteFood/{id}")
	// Path variable---->its a spring boot annotation to handle template variables in the request URI mapping, and set them as method parameters
	public ResponseEntity<String> deleteFood(@PathVariable int id){
		foodDetailsService.deleteFood(id);
		return new ResponseEntity<String>("Food deleted successfully", HttpStatus.OK);
	}
	@PutMapping("/updateFood/{id}")
	//Response Body--> to handle template variables in the request URI mapping, and set them as method parameters
	public ResponseEntity<String> updateFood(@PathVariable int id, @RequestBody Food_Details food){
		foodDetailsService.updateFood(id, food);
		return new ResponseEntity<String>("Food update successfully", HttpStatus.OK);
	}
	
}
