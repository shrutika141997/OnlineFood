package com.cybage.Repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.cybage.model.Offers;

@Repository
public interface Offer_Repository extends JpaRepository<Offers,Integer> {

}
