package com.cybage.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cybage.Repository.FoodCategory_Repository;
import com.cybage.Repository.FoodDetails_Repository;
import com.cybage.model.Food_Details;



@Service
public class FoodDetails_Service {
	
	@Autowired
	FoodCategory_Repository foodCategoryRepository;
	
	@Autowired
	FoodDetails_Repository foodDetailsRepository;

	public List<Food_Details> getAll() {
		
	
		return foodDetailsRepository.findAll() ;
	}

	public void addFood(Food_Details food) {
		foodDetailsRepository.save(food);
		
	}

	public void deleteFood(int id) {
		foodDetailsRepository.deleteById(id);
	
	}

	public Food_Details updateFood(int id, Food_Details food) {
		
		
		return foodDetailsRepository.save(food);
	}
	

}
