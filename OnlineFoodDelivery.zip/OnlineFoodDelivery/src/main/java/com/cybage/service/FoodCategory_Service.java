package com.cybage.service;

import java.util.List;


import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cybage.Repository.FoodCategory_Repository;
import com.cybage.model.Food_Category;

@Service
public class FoodCategory_Service {
	@Autowired
	FoodCategory_Repository foodCategoryRepository;

	public List<Food_Category> getAll() {
		
		return foodCategoryRepository.findAll();
	}

	public void addCategory(Food_Category category) {
		
		foodCategoryRepository.save(category);
		
	}

	public void deleteCategory(int id) {
		
		foodCategoryRepository.deleteById(id);
	}

	public Food_Category updateCategory(int id, Food_Category category) {
		return foodCategoryRepository.save(category);
		
	}

}
