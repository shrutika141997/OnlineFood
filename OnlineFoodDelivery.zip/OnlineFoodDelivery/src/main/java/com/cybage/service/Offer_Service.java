package com.cybage.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cybage.Repository.Offer_Repository;
import com.cybage.model.Offers;

@Service
public class Offer_Service {
	
	@Autowired
	
	Offer_Repository offer_Repository;

	public  List<Offers> getAll() {
		
		return offer_Repository.findAll();
	}

	public void addOffer(Offers offer) {
		
		offer_Repository.save(offer);
		
	}

	public void deleteOffer(int id) {
		
		offer_Repository.deleteById(id);
		
	}

	public void updateOffer(int id, Offers offer) {
		
		
	}

}
